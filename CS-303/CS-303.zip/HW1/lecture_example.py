# This is from the first lecture example the professor did in class

